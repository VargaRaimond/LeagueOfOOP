package heroes.abilities;

public enum AbilityType { Drain, Deflect, Fireblast, Ignite, Execute, Slam, Backstab, Paralysis }
