package heroes;

public enum PlayerType { Wizard, Rogue, Knight, Pyromancer }

