package map;

public enum LandType { Land, Volcanic, Desert, Woods
}
